Output_file & save are added to export html. file for submission
HoverTool is also added from the bokeh.models since it is required by the task of this assignment